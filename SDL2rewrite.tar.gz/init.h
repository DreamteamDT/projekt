#include "defandstruct.h"
extern Game game;
