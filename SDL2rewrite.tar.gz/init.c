 #include "init.h"

 void init()
 {
     if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO)<0)
     {
          printf("Could not initialize SDL. %s\n",SDL_GetError());
          exit(1);
     }
     game.window = NULL;
     game.screen = NULL;

     game.window = SDL_CreateWindow("SDL Tutorial",SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
         if(game.window == NULL)
         {
            printf("Window could not be created! SDL_Error: %s\n",SDL_GetError());
         }
         else
         {
            game.screen = SDL_GetWindowSurface(game.window);
         }

}
void cleanup()
{
     SDL_DestroyWindow(game.window);
     SDL_Quit();


}
