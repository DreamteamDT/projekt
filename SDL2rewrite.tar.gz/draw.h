#include "defandstruct.h"

Game game;
