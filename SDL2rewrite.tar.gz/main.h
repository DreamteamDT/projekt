#include "defandstruct.h"
Game game;



//temporary

Sprite *rendertarget;
