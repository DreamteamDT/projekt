#include "main.h"
extern void init();
extern void cleanup();
extern void draw();
int main(int argc, char *argv[])
{
    int game = 0;
    init();

    atexit(cleanup);

    game = 1;



    while(game)
    {
       draw();

    }

    return 0;
}
