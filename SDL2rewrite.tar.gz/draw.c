#include "draw.h"

void draw()
{
            SDL_FillRect(game.screen,NULL,SDL_MapRGB(game.screen->format,0xFF,0xFF,0xFF));

            SDL_UpdateWindowSurface(game.window);

            SDL_Delay(2000);
}
