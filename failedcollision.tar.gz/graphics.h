#include "structs.h"

extern Sprite sprite[MAX_SPRITES];
extern Entity *self,extra;
extern Game game;
extern Entity rectA;
