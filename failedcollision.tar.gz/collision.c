#include "collision.h"
int hit(int,int,int,int,int,int,int,int);

void collisionmap()
{

/*
    rectA.rectangle.w =30;
    rectA.rectangle.h=100;
    rectA.rectangle.x = 40;
    rectA.rectangle.y =40;

*/
bool thing = false;

    if(entity[BULLET_SPRITE].active==1)
    {
       printf("printf: %d\n",entity[BULLET_SPRITE].x);
    }
        /*if(hit(entity[BULLET_SPRITE].x,entity[BULLET_SPRITE].y,entity[BULLET_SPRITE].sprite->w,entity[BULLET_SPRITE].sprite->h,330,24,21,2))
       {
          printf("hit");
       }
       */
  //  pintf("\nstate: %d",thing);



}


int hit(int x0, int y0, int w0, int h0, int x2, int y2, int w2, int h2)
{

    SDL_Rect r1,r2;
    r1.x = x0;
    r1.y = y0;
    r1.w = w0;
    r1.h = h0;

    r2.x = x2;
    r2.y = y2;
    r2.w = w2;
    r2.h = h2;


	return !(r2.x > (r1.x + r1.w) ||
           (r2.x + r2.w) < r1.x ||
           r2.y > (r1.y + r1.h) ||
           (r2.y + r2.h) < r1.y);

}

