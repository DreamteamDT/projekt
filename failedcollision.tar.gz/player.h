#include "structs.h"

extern Entity player,extra;
extern Control input;
