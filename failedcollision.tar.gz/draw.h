#include "structs.h"

Game game;
Entity rectA;
