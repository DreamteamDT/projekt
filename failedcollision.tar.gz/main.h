#include "structs.h"

Game game;
Control input;
Entity player,extra, *self, entity[MAX_ENTITIES];
Sprite sprite[MAX_SPRITES];
Sound sound[MAX_SOUNDS];
Entity rectA;
