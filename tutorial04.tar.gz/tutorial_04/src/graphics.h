#include "structs.h"

extern Sprites sprite[MAX_SPRITES];
extern Game game;
