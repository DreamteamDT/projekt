#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"

#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

enum
{
	PLAYER_SPRITE,
	MAX_SPRITES
};
