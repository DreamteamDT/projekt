#include "structs.h"

extern Entity player;
extern Control input;
extern Sprites sprites[MAX_SPRITES];
