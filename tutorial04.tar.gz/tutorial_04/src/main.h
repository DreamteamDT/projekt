#include "structs.h"

Game game;
Control input;
Entity player;
Sprites sprite[MAX_SPRITES];
