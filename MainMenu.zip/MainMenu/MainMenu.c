#include <SDL.h>
#include <stdio.h>
#include <stdbool.h>

//F�nsterstorlek
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

//Startar SDL och �ppnar ett f�nster
bool init();

//Laddar media
bool loadMedia();

//Friar media och st�nger av SDL
void close();

//Gubben man valt
void character();

//Menyn f�r att v�lja gubbe
bool chooseCharacter();

//F�nstrets som media ska renderas till
SDL_Window* gWindow = NULL;

//Ytan inom f�nstret
SDL_Surface* gScreenSurface = NULL;

//Bakgrunden
SDL_Surface* gBakgrund = NULL;

bool init()
{
	//Initialiseringsflaggan
	bool success=true;

	//Initialisera SDL
	if(SDL_Init(SDL_INIT_VIDEO)<0)
	{
		printf("SDL could not initialize! SDL_Error: %s\n",SDL_GetError());
		success=false;
	}
	else
	{
		//Skapa f�nster
		gWindow=SDL_CreateWindow("SDL Tutorial",SDL_WINDOWPOS_UNDEFINED,SDL_WINDOWPOS_UNDEFINED,SCREEN_WIDTH,SCREEN_HEIGHT,SDL_WINDOW_SHOWN);
		if(gWindow==NULL)
		{
			printf("Window could not be created! SDL_Error: %s\n",SDL_GetError());
			success=false;
		}
		else
		{
			//Visa bakgrunden i f�nstret
			gScreenSurface=SDL_GetWindowSurface(gWindow);
		}
	}

	return success;
}

bool loadMedia(int imageNo)
{
    if(imageNo==1)
    {
        //Huvudmenyn
        gBakgrund=SDL_LoadBMP("MainMenu.bmp");
    }
    else if(imageNo==2)
    {
        //Menyn f�r att v�lja gubbe
        gBakgrund=SDL_LoadBMP("ChooseCharacter.bmp");
    }
    else if(imageNo==3)
    {
        //Menyn f�r att v�lja gubbe
        gBakgrund=SDL_LoadBMP("Connecting.bmp");
    }
	//Ladda successflaggan
	bool success=true;

	if(gBakgrund==NULL)
	{
	    //Laddningen av bakgrunden misslyckades
		printf("Unable to load image %s! SDL Error: %s\n","bakgrund.bmp",SDL_GetError());
		success = false;
	}

	return success;
}

void close()
{
	//Ta bort bakgrunden fr�n f�nstret
	SDL_FreeSurface(gBakgrund);
	gBakgrund=NULL;

	//St�ng ner f�nstret
	SDL_DestroyWindow(gWindow);
	gWindow=NULL;

	//St�ng av SDL
	SDL_Quit();
}

void character(int characterNo)
{
    if(characterNo==1)
    {
        printf("Character One\n");
    }
    else if(characterNo==2)
    {
        printf("Character Two\n");
    }
    else if(characterNo==3)
    {
        printf("Character Three\n");
    }
    else if(characterNo==4)
    {
        printf("Character Four\n");
    }

    loadMedia(3);
}

bool chooseCharacter()
{
    int x, y;
    SDL_Event e;
    bool quit=false;
    loadMedia(2); //Laddar upp "Choose Character"-bilden

			//Medan f�nstret �r �ppet
			while(!quit)
			{
				//Hantera eventer som st�r p� k�
				while(SDL_PollEvent(&e)!=0)
				{
				    //Positionen p� musen i x-led och y-led
				    SDL_GetMouseState(&x, &y);
                    //printf("x=%d \ny=%d\n", x, y);
					//St�ng f�nstret om anv�ndaren klickar p� X-rutan p� f�nstret
					if(e.type==SDL_QUIT)
					{
						quit=true;
					}
					//St�ng f�nstret om anv�ndaren trycker p� ESC-knappen p� tangentbordet
					else if(e.key.keysym.sym==SDLK_ESCAPE)
                    {
                        quit=true;
                    }
                    //�terg� till huvudmenyn om anv�ndaren trycker back-pilen genom ett v�nsterklick
                    else if(x>250 && x<379 && y>391 && y<453 && e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                        {
                            //Laddar upp huvudmenyn p� f�nstret och programr�knaren �terg�r till main-loopen
                            loadMedia(1);
                            return quit;
                        }
                    }
                    //Anv�ndaren v�ljer f�rsta gubben
                    else if(x>82 && x<151 && y>223 && y<310 && e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                        {
                            character(1);
                        }
                    }
                    //Anv�ndaren v�ljer andra gubben
                    else if(x>215 && x<273 && y>223 && y<310 && e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                        {
                            character(2);
                        }
                    }
                    //Anv�ndaren v�ljer tredje gubben
                    else if(x>343 && x<418 && y>223 && y<310 && e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                        {
                            character(3);
                        }
                    }
                    //Anv�ndaren v�ljer fj�rde gubben
                    else if(x>482 && x<544 && y>223 && y<310 && e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                        {
                            character(4);
                        }
                    }


				}
				//Visa bakgrunden p� f�nstret
				SDL_BlitSurface(gBakgrund,NULL,gScreenSurface,NULL);

				//Uppdatera f�nstret
				SDL_UpdateWindowSurface(gWindow);
			}

			return quit;
}

int main( int argc, char* args[] )
{
	//Starta SDL och skapa ett f�nster
	int imageNo=1, x, y;
	if(!init())
	{
		printf("Failed to initialize!\n");
	}
	else
	{
		//Ladda huvudmenyn
		if(!loadMedia(1))
		{
			printf("Failed to load media!\n");
		}
		else
		{
			//Loop-flaggan i huvudfunktionen
			bool quit=false;

			//Eventhanteraren
			SDL_Event e;

			//Medan f�nstret �r �ppet
			while(!quit)
			{
				//Hantera eventer som st�r p� k�
				while(SDL_PollEvent(&e)!=0)
				{
				    SDL_GetMouseState(&x, &y);
                    //printf("x=%d \ny=%d\n", x, y);
					//St�ng f�nstret & avsluta SDL om anv�ndaren klickar p� X-rutan p� f�nstret
					if(e.type==SDL_QUIT)
					{
						quit=true;
					}
					//St�ng f�nstret & avsluta SDL om anv�ndaren trycker p� ESC-knappen p� tangentbordet
					else if(e.key.keysym.sym==SDLK_ESCAPE)
                    {
                        quit=true;
                    }
                    //G� till menyn "Choose Character" om anv�ndaren trycker p� "Play Game"
                    else if(x>141 && x<455 && y>172 && y<256 && e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                        {
                            chooseCharacter(); //G�r till funktionen f�r "Choose Character"
                        }
                    }
                    //St�ng f�nstret & avsluta SDL om anv�ndaren trycker p� "Exit"
                    else if(x>141 && x<455 && y>270 && y<349 && e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                        {
                            quit=true;
                        }
                    }
				}

				//Visa bakgrunden p� f�nstret
				SDL_BlitSurface(gBakgrund,NULL,gScreenSurface,NULL);

				//Uppdatera f�nstret
				SDL_UpdateWindowSurface(gWindow);
			}
		}
	}

	//St�ng ner f�nstret och SDL
	close();

	return 0;
}
