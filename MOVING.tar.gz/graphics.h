#include "structs.h"

extern Sprite sprite[MAX_SPRITES];
extern Game game;
