#include "structs.h"

extern Entity player;
extern Control input;
