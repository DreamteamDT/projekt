#include "graphics.h"
SDL_ROTOZOOM_SCOPE SDL_Surface *rotozoomSurface(SDL_Surface *src,double angle,double zoom, int smooth);

SDL_Surface *loadImage(char *name)
{
	/* Load the image using SDL Image */

	SDL_Surface *temp = IMG_Load(name);
	SDL_Surface *image;

	if (temp == NULL)
	{
		printf("Failed to load image %s\n", name);

		return NULL;
	}

	/* Make the background transparent */

	SDL_SetColorKey(temp, (SDL_SRCCOLORKEY|SDL_RLEACCEL), SDL_MapRGB(temp->format, 0, 0, 0));

	/* Convert the image to the screen's native format */

	image = SDL_DisplayFormat(temp);

	SDL_FreeSurface(temp);

	if (image == NULL)
	{
		printf("Failed to convert image %s to native format\n", name);

		return NULL;
	}

	/* Return the processed image */

	return image;
}
void drawBullet(SDL_Surface *Bimage, int x, int y,int z)
{
     SDL_Rect dest;
     SDL_Surface *rotatedimage = rotozoomSurface(Bimage,180,1,0);


     dest.x = x;
     dest.y = y;
     dest.w = rotatedimage->w;
     dest.h = rotatedimage->h;

	/* Blit the entire image onto the screen at coordinates x and y */

	SDL_BlitSurface(rotatedimage, NULL, game.screen, &dest);
	//printf("Faggot!");
}
void drawImage(SDL_Surface *image, int x, int y, int FRx, int FRy)
{
	SDL_Rect dest;

	SDL_Rect Src;

	Src.x = FRx;
	Src.y = FRy;
    Src.w = 32;
    Src.h = 32;
	/* Set the blitting rectangle to the size of the src image */

	dest.x = x;
	dest.y = y;


	/* Blit the entire image onto the screen at coordinates x and y */

	SDL_BlitSurface(image, &Src, game.screen, &dest);
}

void loadSprite(int index, char *name)
{
	/* Load the image into the next slot in the sprite bank */

	if (index >= MAX_SPRITES || index < 0)
	{
		printf("Invalid index for sprite! Index: %d Maximum: %d\n", index, MAX_SPRITES);

		exit(1);
	}

	sprite[index].image = loadImage(name);

	if (sprite[index].image == NULL)
	{
		exit(1);
	}
}

SDL_Surface *getSprite(int index)
{
	if (index >= MAX_SPRITES || index < 0)
	{
		printf("Invalid index for sprite! Index: %d Maximum: %d\n", index, MAX_SPRITES);

		exit(1);
	}

	return sprite[index].image;
}

void freeSprites()
{
	int i;

	/* Loop through the sprite bank and clear the images */

	for (i=0;i<MAX_SPRITES;i++)
	{
		if (sprite[i].image != NULL)
		{
			SDL_FreeSurface(sprite[i].image);
		}
	}
}

void loadAllSprites()
{
	loadSprite(PLAYER_SPRITE, "gfx/multiprotago.png");
	loadSprite(BULLET_SPRITE, "gfx/bullet.png");
}
