#include "structs.h"

extern Control input;
