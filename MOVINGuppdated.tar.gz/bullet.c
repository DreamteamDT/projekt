#include "bullet.h"

extern int getFreeEntity(void);
extern void drawStandardEntity(void);
extern SDL_Surface *getSprite(int);
extern void playSound(int);

SDL_Surface *ROTATESPRITE(int z);
static void moveStandardBullet(void);

SDL_ROTOZOOM_SCOPE SDL_Surface *rotozoomSurface(SDL_Surface *src,double angle,double zoom, int smooth);

void addBullet(int x, int y, int z)
{
	int i = getFreeEntity();
    SDL_Surface *presprite;
	if (i == -1)
	{
		printf("Couldn't get a free slot for a bullet!\n");

		return;
	}

	entity[i].x = x;
	entity[i].y = y;

	entity[i].Fx = z;
    presprite = ROTATESPRITE(z);
	entity[i].action = &moveStandardBullet;
	entity[i].draw = &drawStandardEntity;
//	entity[i].sprite = getSprite(BULLET_SPRITE);

    entity[i].sprite = presprite;
	/* Play a sound when the shot is fired */
	playSound(BULLET_SOUND);
}

SDL_Surface *ROTATESPRITE(int z)
{
     SDL_Surface *mySprite;
     mySprite = getSprite(BULLET_SPRITE);
     printf("display: %d\n",z);
     SDL_Surface *rotatedimage;
     double angle;
     if(z == 0 || z == 32)
     {
         rotatedimage = rotozoomSurface(mySprite,270,1,0);
     }
     if(z == 64 || z == 96)
     {
         rotatedimage = rotozoomSurface(mySprite,90,1,0);
     }
     if(z == 128 || z == 160)
     {
         rotatedimage = mySprite;
     }
     if(z == 192 || z == 224)
     {
         rotatedimage = rotozoomSurface(mySprite,180,1,0);
     }
     if(z ==  256 || z == 282)
     {
         rotatedimage = rotozoomSurface(mySprite,225,1,0);
     }
     if(z == 320 || z == 356)
     {
         rotatedimage = rotozoomSurface(mySprite,315,1,0);
     }
     if(z == 384 || z == 416)
     {
         rotatedimage = rotozoomSurface(mySprite,45,1,0);
     }
     if(z == 480 || z == 512)
     {
         rotatedimage = rotozoomSurface(mySprite,135,1,0);
     }

     return rotatedimage;
}

static void moveStandardBullet()
{
	/* Move the bullet across the screen */
    if(self->Fx == 64 || self->Fx == 96) /*when sprite is facing up*/
    {
        self-> y -=BULLET_SPEED;
    }
    if(self->Fx == 0 || self->Fx == 32) /*sprite is facing down*/
    {
        self-> y += BULLET_SPEED;
    }
    if(self->Fx == 192 || self->Fx == 224)
    {
        self -> x -= BULLET_SPEED;
    }
    if(self ->Fx == 128 || self->Fx == 160)
    {
        self-> x += BULLET_SPEED;
    }
    if(self->Fx == 256 || self -> Fx == 288)
    {
        self-> x -= BULLET_SPEED;
        self-> y += BULLET_SPEED;
    }
    if(self ->Fx == 320 || self->Fx== 352)
	{
	    self-> x += BULLET_SPEED-5;
	    self-> y += BULLET_SPEED-5;
	}
	if(self ->Fx == 384 || self->Fx == 416)
	{
	    self-> x+= BULLET_SPEED;
	    self-> y-= BULLET_SPEED;
	}
    /* Kill the bullet if it moves off the screen */
    if(self -> Fx == 480 || self-> Fx == 512)
    {
        self-> x-= BULLET_SPEED;
        self-> y-= BULLET_SPEED;
    }
	if (self->x >= SCREEN_WIDTH)
	{
		self->active = 0;
	}
	if (self->x <= 0)
	{
	    self->active = 0;
    }
}
