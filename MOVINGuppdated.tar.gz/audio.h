#include "structs.h"

extern Sound sound[MAX_SOUNDS];
