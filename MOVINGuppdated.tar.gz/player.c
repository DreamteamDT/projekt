#include "player.h"

extern int loadSprite(char *);
extern void drawImage(SDL_Surface *, int, int,int,int);
extern void addBullet(int, int,int);
extern SDL_Surface *getSprite(int);

void initPlayer()
{
	player.sprite = getSprite(PLAYER_SPRITE);

	player.x = SCREEN_WIDTH / 2;
	player.y = SCREEN_HEIGHT / 2;
	player.Fx = 0;
	player.Fy = 0;
}

void doPlayer()
{
	player.thinkTime--;

	if (player.thinkTime <= 0)
	{
		player.thinkTime = 0;
	}

	if (input.up == 1)
	{
		if(player.Fx == 64)
		{
           player.Fx = 96;
		}
		else
		{
		   player.Fx = 64;
		}
		player.y -= PLAYER_SPEED;

		/* Don't allow the player to move off the screen */

		if (player.y < 0)
		{
			player.y = 0;
		}
	}

	if (input.down == 1)
	{
		if(player.Fx == 0)
		{
		   player.Fx = 32;
		}
		else
		{
		   player.Fx = 0;
		}
		player.y += PLAYER_SPEED;

		/* Don't allow the player to move off the screen */

		if (player.y + player.sprite->h >= SCREEN_HEIGHT)
		{
			player.y = SCREEN_HEIGHT - 32;
		}
	}

	if (input.left == 1)
	{
		if(player.Fx == 192)
		{
		    player.Fx = 224;
		}
		else
		{
		    player.Fx = 192;
		}

		player.x -= PLAYER_SPEED;

		/* Don't allow the player to move off the screen */

		if (player.x < 0)
		{
			player.x = 0;
		}
	}

	if (input.right == 1)
	{
		if(player.Fx == 128)
		{
		   player.Fx = 160;
		}
		else
		{
		   player.Fx = 128;
		}

		player.x += PLAYER_SPEED;

		/* Don't allow the player to move off the screen */

		if (player.x >= SCREEN_WIDTH-32)
		{
			player.x = SCREEN_WIDTH-32;
		}
	}
	if(input.down == 1 && input.left == 1)
	{
	     if(player.Fx == 256)
	     {
	        player.Fx = 282;
	     }
	     else
	     {
	        player.Fx = 256;
	     }
         player.x -= PLAYER_SPEED-3;
	     player.y += PLAYER_SPEED-3;
	}

	if(input.down == 1 && input.right == 1)
	{
	     if(player.Fx == 320)
	     {
	        player.Fx = 352;
	     }
	     else
	     {
	        player.Fx = 320;
	     }

	     player.x += PLAYER_SPEED-3;
	     player.y += PLAYER_SPEED-3;
	}

	if(input.up == 1 && input.right == 1)
	{
	     if(player.Fx == 384)
	     {
	        player.Fx = 416;
	     }
	     else
	     {
	        player.Fx = 384;
	     }

	     player.x += PLAYER_SPEED-3;
	     player.y -= PLAYER_SPEED-3;
	}
    if(input.up == 1 && input.left == 1)
	{
	     if(player.Fx == 480)
	     {
	        player.Fx = 512;
	     }
	     else
	     {
	        player.Fx = 480;
	     }

	     player.x -= PLAYER_SPEED-3;
	     player.y -= PLAYER_SPEED-3;
	}
	if (input.fire == 1)
	{
		/* You can only fire when the thinkTime is 0 or less */

		if (player.thinkTime <= 0)
		{
			addBullet(player.x, player.y + (player.sprite->h / 2),player.Fx);

			player.thinkTime = MAX_RELOAD_TIME;
		}
	}
}

void drawPlayer()
{
	/* Draw the image in the player structure */

	drawImage(player.sprite, player.x, player.y,player.Fx,player.Fy);
}

