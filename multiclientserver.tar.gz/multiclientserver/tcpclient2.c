#include <stdio.h>
#include <stdlib.h>
#ifndef _MSC_VER
#include <unistd.h>
#endif
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_net.h>

struct player{
  int xpos;
  int ypos;
};

int main(int argc, char **argv)
{
  struct player player;
  player.xpos = 10;
  player.ypos = 20;
  SDL_Event event;
  IPaddress ip;
  char tmp[1024];
  int id;
  Uint16 port;
  SDLNet_SocketSet socketset=SDLNet_AllocSocketSet(30);
  /* initialize SDL */
  SDL_Init(SDL_INIT_EVERYTHING);
    
  /* initialize SDL_net */
  SDLNet_Init();
  
  /* get the port from the commandline */
  port=(Uint16) strtol(argv[2],NULL,0);
  
  /* Resolve the argument into an IPaddress type */
  SDLNet_ResolveHost(&ip,argv[1],port);
    
  /* open the server socket */
  TCPsocket sock = SDLNet_TCP_Open(&ip);
  printf("Connected to the server!\n");
  
  SDLNet_TCP_AddSocket(socketset,sock);

  SDL_Window *window;
  window = SDL_CreateWindow("Hej hej",SDL_WINDOWPOS_UNDEFINED,SDL_WINDOWPOS_UNDEFINED,200,150,SDL_WINDOW_OPENGL);
  printf("test\n");
  
  while(1){
    while(SDLNet_CheckSockets(socketset,0)>0){
      
      SDLNet_TCP_Recv(sock,tmp,strlen(tmp)+1);
      sscanf(tmp,"%d %d",&(player.xpos),&(player.ypos));
      printf("Players xpos: %d\tPlayers ypos: %d\n",player.xpos,player.ypos);
    }
    while(SDL_PollEvent(&event) != 0 ){
      if(event.type == SDL_KEYDOWN)
	{
	switch(event.key.keysym.sym){
	case SDLK_1:
	  sprintf(tmp,"%d %d",player.xpos,player.ypos);
	  SDLNet_TCP_Send(sock,tmp,strlen(tmp)+1);
	  break;
	case SDLK_2:
	  sprintf(tmp,"%d %d",player.xpos,player.ypos);
	  SDLNet_TCP_Send(sock,tmp,strlen(tmp)+1);
	  break;
      }
      }
    }
  }
  
  
  
  SDLNet_TCP_Close(sock);
  
  /* shutdown SDL_net */
  SDLNet_Quit();
  
  /* shutdown SDL */
  SDL_Quit();
  
  return(0);
}
