#include "defandstruct.h"
Game game;
Control input;
Sprite playersprite;
Sprite sprite[MAX_SPRITES];


//temporary

