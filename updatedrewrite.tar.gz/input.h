#include "defandstruct.h"

extern Control input;
