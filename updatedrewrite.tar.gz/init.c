 #include "init.h"

 void init()
 {


     //IMG_Init(IMG_INIT_PNG);
     game.window = NULL;
     game.screen = NULL;


    game.window = SDL_CreateWindow("SDL2 Sprite Sheets",
        SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640,
        480, 0);
    game.renderer = SDL_CreateRenderer(game.window, -1, 0);
    SDL_SetRenderDrawColor(game.renderer, 168, 230, 255, 255);
    SDL_RenderClear(game.renderer);

}
void cleanup()
{
     printf("reach here confirmed");
     SDL_FreeSurface(playersprite.image);
     SDL_DestroyTexture(playersprite.texture);
     SDL_DestroyRenderer(game.renderer);
     SDL_DestroyWindow(game.window);
     SDL_DestroyRenderer(game.renderer);
     SDL_DestroyWindow(game.window);
     IMG_Quit();
     SDL_Quit();


     SDL_Quit();


}
