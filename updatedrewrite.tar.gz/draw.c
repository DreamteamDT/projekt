#include "draw.h"

void drawImage(SDL_Texture *image,int x, int y)
{
     SDL_Rect dest;
     dest.x = x;
     dest.y = y;
     dest.w = 32;
     dest.h = 32;
     SDL_RenderCopy(game.renderer,playersprite.texture,NULL,&dest);
}

void drawPlayer()
{
  drawImage(playersprite.texture,playersprite.posX,playersprite.posY);

}
void draw()
{
     
        SDL_RenderClear(game.renderer);
        drawPlayer();
        SDL_RenderPresent(game.renderer);

}


