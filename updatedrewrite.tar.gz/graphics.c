#include "graphics.h"

SDL_Texture *initPlayer()
{
    SDL_Surface *image = IMG_Load("Rocket-icon.png");
    SDL_Texture *texture = SDL_CreateTextureFromSurface(game.renderer,image);
    return texture;
}

