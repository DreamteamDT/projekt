#include "defandstruct.h"

extern Entity player;
extern Control input;
//extern Sprites sprites[MAX_SPRITES];
extern Sprite playersprite;
