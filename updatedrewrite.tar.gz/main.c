#include "main.h"

extern void init(void);
extern void cleanup(void);
extern SDL_Texture *initPlayer(void);
//extern void loadAllSprites(void);
extern void getInput(void);
extern void doPlayer(void);

extern void draw();

int main(int argc, char ** argv)
{
    bool quit = false;
    SDL_Event event;

    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_PNG);

    init();     /*skapa window, lagras i en struct i.e game.window, sen byt till game.render*/
    atexit(cleanup);  /*atexit exekveras bara om vi är färdig med kod*/
/*
    playersprite.image = IMG_Load("Rocket-icon.png");
    playersprite.texture = SDL_CreateTextureFromSurface(game.renderer,playersprite.image);
*/
    playersprite.texture = initPlayer();  /*initialisera splerare av typen SDL_Texture*/
   //playersprite.texture = sprite[PLAYER_SPRITE].texture;
    playersprite.posX = 200;  /*var i render?*/
    playersprite.posY = 10;


    while (!quit)
    {
        /*SDL_PollEvent(&event);

        switch (event.type)
        {
        case SDL_QUIT:
            quit = true;
            break;
        }
        */
        getInput();  /*tangent kod, info lagras i en struct Control*/
        draw();  /*Updatera render*/
        doPlayer(); /*flytta sprite*/
        SDL_Delay(10); /*Dröj lite*/
    }

    return 0;
}
