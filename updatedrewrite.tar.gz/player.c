#include "player.h"
void doPlayer()
{
	if (input.up == 1)
	{
		playersprite.posY -= 3;

		/* Don't allow the player to move off the screen */

		if (playersprite.posY < 0)
		{
			playersprite.posY = 0;
		}
	}

	if (input.down == 1)
	{
		playersprite.posY+= 3;

		/* Don't allow the player to move off the screen */

		if (playersprite.posY + 32 >= SCREEN_HEIGHT)
		{
			playersprite.posY = SCREEN_HEIGHT - (32 + 1);
		}
	}

	if (input.left == 1)
	{
		playersprite.posX -= 3;

		/* Don't allow the player to move off the screen */

		if (playersprite.posX < 0)
		{
			playersprite.posX = 0;
		}
	}

	if (input.right == 1)
	{
		playersprite.posX += 3;

		/* Don't allow the player to move off the screen */

		if (playersprite.posX + 32 >= SCREEN_WIDTH)
		{
			playersprite.posX = SCREEN_WIDTH - (32-1);
		}
	}
}
