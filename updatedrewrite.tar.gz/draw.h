#include "defandstruct.h"

Game game;
Sprite playersprite;
Sprite sprite[MAX_SPRITES];
