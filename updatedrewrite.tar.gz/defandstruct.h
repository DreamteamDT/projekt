#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
//#include <SDL2/SDL_render.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>





#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

#define MAX_ENTITIES 20
#define MAX_RELOAD_TIME 20

#define PLAYER_SPEED 3
#define BULLET_SPEED 10

enum
{
	PLAYER_SPRITE,
 	BULLET_SPRITE,
	MAX_SPRITES
};

enum
{
	BULLET_SOUND,
 	MAX_SOUNDS
};

enum
{
	TYPE_BULLET,
 	TYPE_ENEMY
};

typedef struct Game
{
	SDL_Surface *screen;
	SDL_Window *window;
	SDL_Renderer *renderer;
	SDL_Texture *texture;
} Game;

typedef struct Sprite
{
	SDL_Surface *image;
	SDL_Renderer *renderer;
	SDL_Texture *texture;
	int posX;
	int posY;
} Sprite;
/*
typedef struct Sound
{
	Mix_Chunk *effect;
} Sound;
*/
typedef struct Entity
{
	int active, type;
	int x, y, thinkTime;
	int Fx,Fy;
	SDL_Surface *sprite;
	SDL_Renderer *renderer;
	void (*action)(void);
	void (*draw)(void);
} Entity;

typedef struct Control
{
	int up, down, left, right, fire;
} Control;

