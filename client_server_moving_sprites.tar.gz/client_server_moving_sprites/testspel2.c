#include <SDL/SDL.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_net.h>

const int WINDOW_WIDTH = 640;
const int WINDOW_HEIGHT = 480;
const char* WINDOW_TITLE = "SDL Start";

int uncomplete_string(char tmp[]){
  int i=0;
  while(tmp[i]!='\0'){
    if(tmp[i]=='\n')
      return 0;
    i++;
  }
  return 1;
}

int main(int argc, char **argv)
{
  IPaddress ip;
  char tmp[1024];
  int id;
  Uint16 port;
  SDLNet_SocketSet socketset=SDLNet_AllocSocketSet(30);
  SDL_Init( SDL_INIT_EVERYTHING );
  SDLNet_Init();
  port=(Uint16) strtol(argv[2],NULL,0);
  SDLNet_ResolveHost(&ip,argv[1],port);
  TCPsocket sock = SDLNet_TCP_Open(&ip);
  if(!sock){
    printf("Couldnt open socket\n");
    return 1;
  }
  SDLNet_TCP_AddSocket(socketset,sock);
  int test;
  
  SDL_Surface* screen = SDL_SetVideoMode( WINDOW_WIDTH, WINDOW_HEIGHT, 0,
      SDL_HWSURFACE | SDL_DOUBLEBUF );
   SDL_WM_SetCaption( WINDOW_TITLE, 0 );

   SDL_Surface* bitmap = SDL_LoadBMP("bat.bmp");
   SDL_SetColorKey(bitmap, SDL_SRCCOLORKEY, SDL_MapRGB(bitmap->format, 255, 0, 255));
   SDL_Surface* enemymap = SDL_LoadBMP("bat.bmp");
   SDL_SetColorKey(enemymap, SDL_SRCCOLORKEY, SDL_MapRGB(enemymap->format, 255 ,0 , 255));
   int change=0;
   int batImageX = 20;
   int batImageY = 58;
   int batWidth = 75;
   int batHeight = 50;

   // We change these to make the bat move
   int batX = 100;
   int batY = 100;
   int enemyX = 100;
   int enemyY = 100;
   int exist=0;
   SDL_Event event;
   bool gameRunning = true;

   SDL_Rect batSource;
   batSource.x = batImageX;
   batSource.y = batImageY;
   batSource.w = batWidth;
   batSource.h = batHeight;

   SDL_Rect batDest;
   batDest.x = batX;
   batDest.y = batY;
   batDest.w = batWidth;
   batDest.h = batHeight;

   SDL_Rect enemySource;
   enemySource.x = batImageX;
   enemySource.y = batImageY;
   enemySource.w = batWidth;
   enemySource.h = batHeight;

   SDL_Rect enemyDest;
   enemyDest.w = batWidth;
   enemyDest.h = batHeight;
   SDL_EnableKeyRepeat(20,20);
   
   while (gameRunning)
   {
     while(SDLNet_CheckSockets(socketset,0)>0){
       int offset = 0;
       exist = 1;
       int test;
       do{
	 SDLNet_TCP_Recv(sock,tmp+offset,1024);
	 printf("%d\n",strlen(tmp));
       }while(uncomplete_string(tmp));
       sscanf(tmp,"%d %d",&enemyX,&enemyY);
       printf("Fiendens x pos: %d\n",enemyX);
       printf("Fiendens y pos: %d\n",enemyY);
       
     }
      // Handle input
     while(SDL_PollEvent(&event) != 0){
       if(event.type == SDL_KEYDOWN){
	 switch(event.key.keysym.sym){
	 case SDLK_UP:
	   batY -= 1;
	   change = 1;
	   if(batY<0)batY=0;
	   break;
	 case SDLK_DOWN:
	   batY += 1;
	   change = 1;
	   if(batY>436)batY=436;
	   break;
	 case SDLK_LEFT:
	   batX -= 1;
	   change = 1;
	   if(batX<0)batX=0;
	   break;
	 case SDLK_RIGHT:
	   batX += 1;
	   change = 1;
	   if(batX>575)batX=575;
	   break;
	 case SDLK_1:
	   gameRunning = 0;
	 default:
	   break;
	 }
	 if(change){
	   sprintf(tmp,"%d %d \n",batX,batY);
	   //  printf("%s\n",tmp);
	   int size=0;
	   int len=strlen(tmp);
	     while(size<len){
	     
	   size+=SDLNet_TCP_Send(sock,tmp+size,len-size);
	   
	      }
	   change = 0;
	 }
	 change = 0;
       }
       
     }
      if(exist){
	 enemyDest.x = enemyX;
	 enemyDest.y = enemyY;
       	 SDL_FillRect(screen,NULL,SDL_MapRGB(screen->format,0,0,0));
	 SDL_BlitSurface(enemymap,&enemySource,screen,&enemyDest);
	 SDL_Flip(screen);
	    }
      // Draw the scene
       batDest.x = batX;
       batDest.y = batY;
      
       SDL_FillRect(screen,&batDest, SDL_MapRGB(screen->format, 0, 0, 0));
       SDL_BlitSurface(bitmap,&batSource,screen,&batDest);
       SDL_Flip(screen);
       SDL_Delay(5);
   }

   SDLNet_TCP_Close(sock);
   SDLNet_Quit();
   SDL_FreeSurface(enemymap);
   SDL_FreeSurface(bitmap);
   SDL_FreeSurface(screen);

   SDL_Quit();

   return 0;
}
