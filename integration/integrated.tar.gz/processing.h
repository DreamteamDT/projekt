#include "definition.h"
extern int global;
extern Program program;
