#include "definition.h"

Program program;
