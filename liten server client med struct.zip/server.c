#include <stdio.h>
#include <SDL.h>
#include <SDL_net.h>
#include <string.h>

int main(int argc, char* argv[])
{
    SDL_Init(SDL_INIT_EVERYTHING);
    SDLNet_Init();

    IPaddress ip;
    SDLNet_ResolveHost(&ip,NULL,1234);

    TCPsocket server=SDLNet_TCP_Open(&ip);
    TCPsocket client;
    TCPsocket client2;

    int t = 0;
    char text[10000];
    char tmp[10000];
    while(1)
    {
        client=SDLNet_TCP_Accept(server);
        if(client)
        {
            SDLNet_TCP_Recv(client,text,10000);
            if (tmp[0] == 0){
                //SDLNet_TCP_Send(client,text,strlen(text)+1);
            }
            if (tmp[0] == 1){
                SDLNet_TCP_Send(client,text,strlen(text)+1);
                break;
            }
        }
    }
    SDLNet_TCP_Close(server);

    SDLNet_Quit();
    SDL_Quit();
}

