//a simple client for networking with SDL_Net
#include <stdio.h>
#include <SDL.h>
#include <SDL_net.h>
#include <string.h>

int main(int argc, char* argv[])
{
    SDL_Init(SDL_INIT_EVERYTHING);
    SDLNet_Init();

    IPaddress ip;
    //write "127.0.0.1",1234 to connect to the server.cpp on your local machine
    SDLNet_ResolveHost(&ip,"127.0.0.1",1234);

    TCPsocket client2=SDLNet_TCP_Open(&ip);
    TCPsocket server;

    char text2[10000];
    const char* text="Hello Client1!\n";
    int t = 1;

    if (t == 0)
        SDLNet_TCP_Send(client2,text,strlen(text)+1);
    else if (t == 1){
        SDLNet_TCP_Recv(client2,text2,10000);
        printf("%s\n", text2);
    }
    SDLNet_TCP_Close(client2);

    SDLNet_Quit();
    SDL_Quit();
}

